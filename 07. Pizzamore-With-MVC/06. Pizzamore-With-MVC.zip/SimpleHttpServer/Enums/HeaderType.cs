﻿namespace SimpleHttpServer.Enums
{
    public enum HeaderType
    {
        HttpRequest,
        HttpResponse
    }
}
