﻿namespace SimpleHttpServer.Enums
{
    public enum RequestMethod
    {
        GET,
        POST
    }
}
