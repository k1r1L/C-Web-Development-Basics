﻿namespace SimpleMVC.App.BindingModels
{
    public class AddPizzaBindingModel
    {
        public string Title { get; set; }

        public string Recipe { get; set; }

        public string ImageUrl { get; set; }
    }
}
