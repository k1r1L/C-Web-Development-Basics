﻿namespace SimpleMVC.App.BindingModels
{
    public class RegisterUserBindingModel
    {
        public string SignUpEmail { get; set; }

        public string SignUpPassword { get; set; }
    }
}
