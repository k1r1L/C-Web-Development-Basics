﻿namespace SimpleMVC.App.MVC.Interfaces
{
    public interface IRedirectable
    {
        string Location { get; }
    }
}
