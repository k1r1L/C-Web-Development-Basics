﻿namespace SimpleMVC.App.MVC.Interfaces
{
    public interface IInvocable : IRedirectable
    {
        string Invoke();
    }
}
