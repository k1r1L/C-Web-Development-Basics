﻿namespace SimpleMVC.App.MVC.Interfaces
{
    public interface IRenderable
    {
        string Render();
    }
}
